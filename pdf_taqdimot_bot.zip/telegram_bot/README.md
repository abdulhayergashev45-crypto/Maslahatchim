# PDF → Taqdimot Telegram bot

Foydalanuvchi PDF kitob yoki darslik yuboradi → bot kerakli qismini AI (Claude)
yordamida tahlil qiladi → chiroyli dizaynli `.pptx` taqdimot qilib qaytaradi.

## Ishlash tartibi

1. Foydalanuvchi botga PDF fayl yuboradi
2. Bot butun kitobni yoki aniq sahifa oralig'ini (masalan `8-33`) tanlashni so'raydi
3. Matn PDF'dan ajratib olinadi
4. Claude API orqali matn slaydlar rejasiga (JSON) aylantiriladi
5. `python-pptx` yordamida tayyor dizaynli taqdimot yaratiladi
6. Bot foydalanuvchiga `.pptx` faylni yuboradi

## O'rnatish

### 1. Talablar
- Python 3.10 yoki undan yuqori
- Telegram bot tokeni ([@BotFather](https://t.me/BotFather) orqali, `/newbot` buyrug'i bilan, bepul)
- Anthropic API kaliti ([console.anthropic.com](https://console.anthropic.com), pullik — foydalanishga qarab hisoblanadi)

### 2. Kutubxonalarni o'rnatish

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Sozlamalar

`.env.example` faylidan nusxa oling va to'ldiring:

```bash
cp .env.example .env
```

`.env` faylini oching va quyidagilarni kiriting:

```
TELEGRAM_BOT_TOKEN=sizning_bot_tokeningiz
ANTHROPIC_API_KEY=sizning_api_kalitingiz
```

### 4. Ishga tushirish

```bash
python bot.py
```

Konsolda `Bot ishga tushdi...` deb chiqsa — bot ishlayapti. Telegram'da botingizga
`/start` yozing va PDF yuboring.

## Fayllar tuzilishi

| Fayl | Vazifasi |
|---|---|
| `bot.py` | Asosiy bot logikasi, Telegram buyruqlari va suhbat oqimi |
| `pdf_utils.py` | PDF'dan matn ajratib olish |
| `ai_utils.py` | Claude API orqali matnni slaydlar rejasiga aylantirish |
| `pptx_utils.py` | JSON reja asosida dizaynli `.pptx` yaratish |
| `requirements.txt` | Kerakli Python kutubxonalari |
| `.env.example` | Sozlamalar namunasi |

## Cheklovlar va bilingan narsalar

- **Fayl hajmi**: PDF 20 MB dan oshmasligi kerak (`bot.py` ichidagi `MAX_PDF_MB` orqali o'zgartirish mumkin)
- **Katta kitoblar**: 40 sahifadan katta kitob uchun butun kitobni tanlash tavsiya etilmaydi — natija juda umumiy bo'lib qolishi mumkin. Aniq bo'lim/sahifalarni tanlash yaxshiroq natija beradi
- **Narx**: Har bir so'rov Anthropic API orqali pullik — matn hajmiga qarab bir necha sentdan bir necha o'n sentgacha bo'lishi mumkin
- **Rasm asosidagi (skanerlangan) PDF'lar**: hozirgi versiya faqat matn qatlami bor PDF'lardan matn oladi (OCR yo'q). Skanerlangan sahifalar uchun OCR qo'shish kerak bo'ladi

## Kengaytirish g'oyalari

- **OCR qo'llab-quvvatlash**: skanerlangan kitoblar uchun `pytesseract` qo'shish
- **Video dars**: taqdimotni audio bilan video darsga aylantirish (ovoz sifatini
  ta'minlash uchun tashqi TTS xizmati — masalan ElevenLabs API — kerak bo'ladi)
- **Ko'p tilda qo'llab-quvvatlash**: hozircha faqat o'zbek tiliga sozlangan
  (`ai_utils.py` ichidagi `SYSTEM_PROMPT`ni tahrirlab boshqa tillarga moslashtirish mumkin)
- **Foydalanuvchi cheklovlari**: kunlik/oylik so'rovlar sonini cheklash (xarajatni nazorat qilish uchun)

## Deploy qilish (doimiy ishlashi uchun)

Kompyuteringizni doim yoniq qoldirish shart emas — arzon variantlar:

- **Railway.app** yoki **Render.com** — bepul/arzon tarif, Python loyihalarini oson joylashtiradi
- **VPS** (masalan, Contabo, Hetzner — oyiga ~3-5$) + `systemd` yoki `screen`/`tmux` orqali botni fonda ishga tushirish
